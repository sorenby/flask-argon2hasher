# Flask-Argon2Hasher

Flask-Argon2Hasher is a Flask extension that provides Argon2 hashing utilities for
your Flask app.

## Installation

Install the extension with the following command:

    $ pip install flask-argon2hasher

## Usage

Examples here